package dev.tawhid.keystrokes;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public final class TawhidKeystrokes implements ClientModInitializer {
    private static final int PANEL_X = 12;
    private static final int PANEL_Y = 42;
    private static final int KEY = 22;
    private static final int GAP = 3;
    private static final int PANEL_BG = 0xB9141822;
    private static final int KEY_IDLE = 0xD92B3445;
    private static final int KEY_DOWN = 0xF04D9EFF;
    private static final int TEXT = 0xFFFFFFFF;

    private final float[] anim = new float[7];
    private final boolean[] previous = new boolean[7];
    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean prevLeft;
    private boolean prevRight;
    private long lastFrameNanos;

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> render(drawContext));
    }

    private void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getWindow() == null) return;

        long now = System.nanoTime();
        float dt = lastFrameNanos == 0 ? 0.016f : Math.min(0.05f, (now - lastFrameNanos) / 1_000_000_000f);
        lastFrameNanos = now;

        long window = mc.getWindow().getHandle();
        boolean[] down = {
            key(window, GLFW.GLFW_KEY_W),
            key(window, GLFW.GLFW_KEY_A),
            key(window, GLFW.GLFW_KEY_S),
            key(window, GLFW.GLFW_KEY_D),
            key(window, GLFW.GLFW_KEY_SPACE),
            key(window, GLFW.GLFW_KEY_LEFT_SHIFT) || key(window, GLFW.GLFW_KEY_RIGHT_SHIFT),
            key(window, GLFW.GLFW_KEY_LEFT_CONTROL) || key(window, GLFW.GLFW_KEY_RIGHT_CONTROL)
        };

        for (int i = 0; i < down.length; i++) {
            float target = down[i] ? 1f : 0f;
            float speed = down[i] ? 22f : 14f;
            anim[i] += (target - anim[i]) * Math.min(1f, dt * speed);
            previous[i] = down[i];
        }

        boolean lmb = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_1) == GLFW.GLFW_PRESS;
        boolean rmb = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_2) == GLFW.GLFW_PRESS;
        if (lmb && !prevLeft) leftClicks.addLast(now);
        if (rmb && !prevRight) rightClicks.addLast(now);
        prevLeft = lmb;
        prevRight = rmb;
        trimClicks(leftClicks, now);
        trimClicks(rightClicks, now);

        int x = PANEL_X;
        int y = PANEL_Y;
        int panelW = KEY * 3 + GAP * 2 + 12;
        int panelH = KEY * 3 + GAP * 2 + 12;
        roundPanel(ctx, x, y, panelW, panelH, PANEL_BG);

        drawKey(ctx, mc, x + 6 + KEY + GAP, y + 6, "W", down[0], anim[0]);
        drawKey(ctx, mc, x + 6, y + 6 + KEY + GAP, "A", down[1], anim[1]);
        drawKey(ctx, mc, x + 6 + KEY + GAP, y + 6 + KEY + GAP, "S", down[2], anim[2]);
        drawKey(ctx, mc, x + 6 + (KEY + GAP) * 2, y + 6 + KEY + GAP, "D", down[3], anim[3]);

        drawKey(ctx, mc, x + 6, y + 6 + (KEY + GAP) * 2, "SPACE", down[4], anim[4]);
        drawKey(ctx, mc, x + 6 + KEY + GAP, y + 6 + (KEY + GAP) * 2, "SHIFT", down[5], anim[5]);
        drawKey(ctx, mc, x + 6 + (KEY + GAP) * 2, y + 6 + (KEY + GAP) * 2, "CTRL", down[6], anim[6]);

        int infoY = y + panelH + 5;
        roundPanel(ctx, x, infoY, panelW, 34, PANEL_BG);
        String cps = "LMB " + leftClicks.size() + "  |  RMB " + rightClicks.size();
        String stats = "FPS " + mc.getCurrentFps() + "  |  PING " + getPing(mc) + "ms";
        ctx.drawText(mc.textRenderer, Text.literal(cps), x + 7, infoY + 5, TEXT, false);
        ctx.drawText(mc.textRenderer, Text.literal(stats), x + 7, infoY + 18, TEXT, false);
    }

    private static boolean key(long window, int key) {
        return GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
    }

    private static void trimClicks(Deque<Long> clicks, long now) {
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1_000_000_000L) {
            clicks.removeFirst();
        }
    }

    private static int getPing(MinecraftClient mc) {
        if (mc.player == null || mc.getNetworkHandler() == null) return 0;
        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return entry == null ? 0 : entry.getLatency();
    }

    private static void roundPanel(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x + 3, y, x + w - 3, y + h, color);
        ctx.fill(x, y + 3, x + w, y + h - 3, color);
        ctx.fill(x + 1, y + 1, x + w - 1, y + h - 1, color);
    }

    private static void drawKey(DrawContext ctx, MinecraftClient mc, int x, int y,
                                String label, boolean down, float amount) {
        int width = label.equals("SPACE") ? KEY : KEY;
        int color = down ? blend(KEY_IDLE, KEY_DOWN, amount) : KEY_IDLE;
        ctx.fill(x, y, x + width, y + KEY, color);
        int inset = 1 + Math.round(amount * 2);
        if (down) ctx.fill(x + inset, y + inset, x + width - inset, y + KEY - inset, 0x334D9EFF);
        int textWidth = mc.textRenderer.getWidth(label);
        int tx = x + (width - textWidth) / 2;
        int ty = y + (KEY - 8) / 2;
        ctx.drawText(mc.textRenderer, Text.literal(label), tx, ty, TEXT, true);
    }

    private static int blend(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24) & 255, ar = (a >>> 16) & 255, ag = (a >>> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >>> 16) & 255, bg = (b >>> 8) & 255, bb = b & 255;
        int ca = (int)(aa + (ba - aa) * t);
        int cr = (int)(ar + (br - ar) * t);
        int cg = (int)(ag + (bg - ag) * t);
        int cb = (int)(ab + (bb - ab) * t);
        return (ca << 24) | (cr << 16) | (cg << 8) | cb;
    }
}
