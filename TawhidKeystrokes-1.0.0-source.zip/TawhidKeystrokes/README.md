# Tawhid Keystrokes

Client-side Fabric HUD project for Minecraft Java 1.21.1.

## Included
- WASD, Space, Shift and Ctrl display
- Smooth, subtle key-press color animation
- LMB/RMB CPS (rolling one-second window)
- FPS and player-list ping
- Lightweight render-time calculations; no background threads

## Build
Requires JDK 21 and internet access for Gradle dependencies.

Run:
- Windows: `gradlew.bat build`
- Linux/macOS: `./gradlew build`

The output JAR will be in `build/libs/`.

## Notes
This is the first source-project build. It is not a precompiled JAR. HUD position and styling are currently fixed near the upper-left corner. The mod is client-only and requires Fabric API.
